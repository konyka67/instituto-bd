<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCampanasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('materias_linea', function (Blueprint $table) {
     
          $table->integer('id_materia_origen')->unsigned();
          $table->integer('id_materia')->unsigned()->nullable();
          $table->timestamps();

          $table->foreign('id_materia')
                ->references('id')
                ->on('materias');

          $table->foreign('id_materia_origen')
                ->references('id')
                ->on('materias');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('materias_linea');
    }
}
