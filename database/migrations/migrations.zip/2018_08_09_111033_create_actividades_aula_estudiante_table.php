<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAsistentesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('actividades_aula_estudiante', function (Blueprint $table) {
            $table->integer('id_actividad')->unsigned(); 
            $table->integer('id_estudiante')->unsigned();          
            $table->string('archivo');       
            $table->timestamps();

            $table->foreign('id_estudiante')
                  ->references('id')
                  ->on('usuarios');
            
            $table->foreign('id_actividad')
                  ->references('id')
                  ->on('actividades_aula');         
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('actividades_aula_estudiante');
    }
}
